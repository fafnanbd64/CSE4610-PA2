public class assumption {
    
    String id;
    String des;
    
    public static void print(String id, String des) {
        System.out.println(id);
        System.out.println(des);

    }
}
