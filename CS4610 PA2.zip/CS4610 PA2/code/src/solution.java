public class solution {
    String id;
    String des;

    public static String des(String id, String des) {
        
        System.out.println(id);
        System.out.println(des);
        return null;
    }
}
