public class context {
    String id;
    String des;
    public static void desc(String id, String des) {
        
        System.out.println(id);
        System.out.println(des);
        
    }
}
